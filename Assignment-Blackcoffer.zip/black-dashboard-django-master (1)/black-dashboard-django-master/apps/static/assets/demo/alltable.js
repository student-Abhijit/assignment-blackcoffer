const dataTable = new simpleDatatables.DataTable("#datatable", {

    searchable: true,
    
    fixedHeight: true,
    
    data: {
    
    headings: ["Video title", "Published Date", "Views Count"],
    }
})
    
    dataTable.rows.add([
        ["ad","354564","2572151"],
        ["ad","3544564","2572151"],
        ["asd","3544564","2572151"],
        ["axd","3544564","25274151"],
        ["adx","35454hh64","25214151"],
        ["asd","354564","252151"],
        ["afd","35452564","252151"],
        ["adnn","354564","252151"],
        ["add","35244564","25214551"],
        ["ajd","354564","252151452"],
        ["avd","354452564","25245151"],
        ["add","35544564","25214551"],
        ["ado","35445564","252151"],
        ["akd","354564","252151"],





    ])