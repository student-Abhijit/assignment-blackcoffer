

# Register your models here.
# In admin.py

from django.contrib import admin
from .models import Insight

admin.site.register(Insight)
