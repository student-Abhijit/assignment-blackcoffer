from django.urls import path
from .import views

urlpatterns = [
    path('total-views', views.totalViews, name="api-total-views"),
    path('datatable_api',views.datatable_api,name= "datatable_api" ),  # for datatables in html page
   
]
