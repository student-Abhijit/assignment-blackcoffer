# serializers.py

from rest_framework import serializers
from .models import Insight

class InsightSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=255)
    topic = serializers.CharField(max_length=100)
    sector = serializers.CharField(max_length=100)
    insight = serializers.CharField()
    url = serializers.URLField()
    region = serializers.CharField(max_length=100)
    country = serializers.CharField(max_length=100)
    published = serializers.DateTimeField()
    relevance = serializers.IntegerField()
    pestle = serializers.CharField(max_length=100)
    source = serializers.CharField(max_length=100)
    likelihood = serializers.IntegerField()
    intensity = serializers.IntegerField()
    start_year = serializers.CharField(max_length=4, allow_blank=True)
    end_year = serializers.CharField(max_length=4, allow_blank=True)
    impact = serializers.CharField(allow_blank=True)
    added = serializers.DateTimeField()

    def create(self, validated_data):
        return Insight.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.title = validated_data.get('title', instance.title)
        instance.topic = validated_data.get('topic', instance.topic)
        instance.sector = validated_data.get('sector', instance.sector)
        instance.insight = validated_data.get('insight', instance.insight)
        instance.url = validated_data.get('url', instance.url)
        instance.region = validated_data.get('region', instance.region)
        instance.country = validated_data.get('country', instance.country)
        instance.published = validated_data.get('published', instance.published)
        instance.relevance = validated_data.get('relevance', instance.relevance)
        instance.pestle = validated_data.get('pestle', instance.pestle)
        instance.source = validated_data.get('source', instance.source)
        instance.likelihood = validated_data.get('likelihood', instance.likelihood)
        instance.intensity = validated_data.get('intensity', instance.intensity)
        instance.start_year = validated_data.get('start_year', instance.start_year)
        instance.end_year = validated_data.get('end_year', instance.end_year)
        instance.impact = validated_data.get('impact', instance.impact)
        instance.added = validated_data.get('added', instance.added)
        instance.save()
        return instance
